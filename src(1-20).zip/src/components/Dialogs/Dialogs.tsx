import React from 'react';
import s from "./Dialogs.module.css"

export const Dialogs = () => {
    return (
        <div>
            Dialogs
        </div>
    );
};
